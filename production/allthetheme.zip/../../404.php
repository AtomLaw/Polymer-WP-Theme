<?php
/**
 * @package WordPress
 * @subpackage AllTheTheme
 * @since AllTheTheme 1.0
 */
 get_header(); ?>

	<h2><?php _e('Error 404 - Page Not Found','allthetheme'); ?></h2>

<?php get_sidebar(); ?>

<?php get_footer(); ?>